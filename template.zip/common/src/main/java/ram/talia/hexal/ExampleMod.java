package ram.talia.hexal;

public final class ExampleMod {
    public static final String MOD_ID = "hexal";

    public static void init() {
        // Write common init code here.
    }
}
