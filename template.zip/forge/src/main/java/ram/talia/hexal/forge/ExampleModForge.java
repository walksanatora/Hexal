package ram.talia.hexal.forge;

import net.minecraftforge.fml.common.Mod;

import ram.talia.hexal.ExampleMod;

@Mod(ExampleMod.MOD_ID)
public final class ExampleModForge {
    public ExampleModForge() {
        // Run our common setup.
        ExampleMod.init();
    }
}
